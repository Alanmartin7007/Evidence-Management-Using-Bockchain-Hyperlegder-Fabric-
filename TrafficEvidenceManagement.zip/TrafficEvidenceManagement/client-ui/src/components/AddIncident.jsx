import React, { useState } from 'react';
import { Form, Button, Input, Select, message, Row, PageHeader, DatePicker } from "antd";
import EmpService from '../services/employeeApi';
const FormItem = Form.Item;
const Option = Select.Option;


const AddIncident = () => {
    const [loading, setLoading] = useState(false);
    const addEmployee = async (values) => {
        try {
            setLoading(true)
            let resp = await EmpService.AddNewEmployee(values)
            const respJSON = JSON.parse(resp)
            
            if (respJSON.status === 'ERROR') {
                message.error(respJSON.description);
            } else if (respJSON.success === false) {
                message.error(respJSON.message);
            } else {
                message.success(respJSON.description);
            }
        } catch (err) {
            message.error(err.message);
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <PageHeader className='site-page-header' title='Add new incident' />
            <Row type="flex" justify="center" align="middle" className='form-wrapper'>
                <Form
                    autoComplete="off"
                    labelCol={{ span: 8 }}
                    wrapperCol={{ span: 16 }}

                    onFinish={addEmployee}

                    onFinishFailed={(error) => {
                        console.log({ error });
                    }}
                >

                    <FormItem
                        name="jobTitle"
                        label="Incident type"
                        rules={[
                            {
                                required: false,
                                message: 'Please select incident type',
                            },
                        ]}
                    >
                        <Select style={{ width: '100%', textAlign:'left' }}
                            placeholder="Select your incident type">
                            <Option value="Traffic Accident">Traffic Accident</Option>
                            {/* <Option value="VP of Marketing">VP of Marketing</Option> */}
                            <Option value="Traffic Violation" selected>Traffic Violation</Option>
                            {/* <Option value="Creative Content Director">Creative Content Director</Option> */}
                        </Select>
                    </FormItem>
                    <FormItem
                        name="empID"
                        label="Vehicle No."
                        rules={[
                            {
                                required: true,
                                message: "Please enter the vehicle number",
                            },
                            { message: "Please enter the vehicle number" },
                        ]}
                        hasFeedback
                    >
                        <Input placeholder="Enter the vehicle number" />
                    </FormItem>
                    <FormItem
                        name="firstName"
                        label="First Name"
                        rules={[
                            {
                                required: true,
                                message: "Please enter first name",
                            },
                            { type: "text", message: "Please enter first name" },
                        ]}
                        hasFeedback
                    >
                        <Input placeholder="Enter first name" />
                    </FormItem>

                    <FormItem
                        name="lastName"
                        label="Last Name"
                        rules={[
                            {
                                required: true,
                                message: "Please enter last name",
                            },
                            { type: "text", message: "Please enter last name" },
                        ]}
                        hasFeedback
                    >
                        <Input placeholder="Enter last name" />
                    </FormItem>

                    {/* <FormItem
                        name="bloodGroup"
                        label="Bloog Group"
                        rules={[
                            {
                                required: false,
                                message: "Please enter blood group",
                            },
                            { type: "text", message: "Please enter blood group" },
                        ]}
                        hasFeedback
                    >
                        <Input placeholder="Enter blood group" />
                    </FormItem> */}

                    <FormItem
                        name="mobile"
                        label="Mobile No."
                        rules={[
                            {
                                required: false,
                            },
                            { message: "Please enter a valid mobile number" },
                        ]}
                        hasFeedback
                    >
                        <Input placeholder="Enter your mobile number" />
                    </FormItem>
                    <FormItem
                        name="address"
                        label="Address"
                        rules={[
                            {
                                required: false,
                            },
                            { type: "text", message: "Please enter address" },
                        ]}
                        hasFeedback
                    >
                        <Input placeholder="Enter address" />
                    </FormItem>
                    {/* <FormItem
                        name="datetime"
                        label="Time"
                        rules={[
                            {
                                required: false,
                            },
                            {type: "text", message: "Enter incident time"},
                        ]}
                        hasFeedback
                    >
                        <DatePicker showTime={{use12Hours: true}} format="DD/MM/YYYY hh:mm A" />   
                    </FormItem> */}
                    <FormItem>
                        <Button type="primary" htmlType="submit" loading={loading} className="save-btn">
                            Save
                        </Button>
                    </FormItem>
                </Form>
            </Row>
        </>
    )

}

export default AddIncident